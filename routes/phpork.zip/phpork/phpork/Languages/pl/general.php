<?php
return [
    "example" => "przykład",
    "word" => "słowo",
    "words" => [
        "good" => "%s dobre słowa",
    ],
];