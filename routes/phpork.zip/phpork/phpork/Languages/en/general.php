<?php 
return [
    "example" => "example",
    "word" => "word",
    "words" => [
        "good" => "%s good words",
    ],
];