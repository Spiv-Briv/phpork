class Item extends Element {
    constructor(node, iterator) {
        super(node, "Item", iterator, "list_category_item_default");
    }
}