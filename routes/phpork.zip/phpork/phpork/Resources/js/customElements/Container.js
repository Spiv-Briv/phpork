class Container extends Element {
    constructor(node, iteration) {
        super(node, "Container", iteration, "container_default");
    }
}